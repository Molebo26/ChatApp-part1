/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp;

/**
 *
 * @author Student
 */
public class Login {
    //----------------------------
    // These variables store the user's details.
    // Once a user registers, their data is saved here
    //----------------------------
    String username;
    String password;
    String phoneNumber; 
     
    //==========================================================================
    // 1. CHECK USERNAME 
    // You are required to ensure:
    //- Username contains an underscore "_"
    // - Username is no more than 5 characters long
    //--------------------------------------------------------------------------
    public boolean checkUserName (String username){
        
        // username .contians ("_") checks for the underscore
        // username.lenght() <=5 ensures that short username
        return username.contains("_") && username.lenght() <= 5; 
    }
        //2. CHECK PASSWORD COMPLEXITY
        // Password requirements:
    public boolean checkPasswordComplexity
            
            
    }
}
