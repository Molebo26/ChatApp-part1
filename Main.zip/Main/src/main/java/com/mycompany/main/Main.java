/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.main;

/* User input is the process of getting typed in information from the end user, 
to get user input we use "Scanner" which is a blueprint for creating objects that 
 can read user input 
 */
//The first thimg we do is to import the Scanner class so we can take input from the user
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        Login loginSystem = new Login();

        String username;
        String password;
        String cellPhone;

        System.out.println("=== USER REGISTRATION ===");

        // USERNAME LOOP
        while (true) {
            System.out.print("Enter username: ");
            username = input.nextLine();

            if (loginSystem.checkUserName(username)) {
                System.out.println("Username successfully captured.");
                break;
            } else {
                System.out.println("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.");
            }
        }

        // PASSWORD LOOP
        while (true) {
            System.out.print("Enter password: ");
            password = input.nextLine();

            if (loginSystem.checkPasswordComplexity(password)) {
                System.out.println("Password successfully captured.");
                break;
            } else {
                System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
            }
        }

        // CELL PHONE LOOP
        while (true) {
            System.out.print("Enter South African cell number (+27...): ");
            cellPhone = input.nextLine();

            if (loginSystem.checkCellPhoneNumber(cellPhone)) {
                System.out.println("Cell phone number successfully added.");
                break;
            } else {
                System.out.println("Cell phone number incorrectly formatted or does not contain international code.");
            }
        }

        // REGISTER USER
        loginSystem.registerUser(username, password, cellPhone);
        System.out.println("Registration complete!\n");

        // LOGIN SECTION
        System.out.println("=== LOGIN ===");

        boolean loggedIn = false;

        while (!loggedIn) {
            System.out.print("Enter username: ");
            String loginUsername = input.nextLine();

            System.out.print("Enter password: ");
            String loginPassword = input.nextLine();

            loggedIn = loginSystem.loginUser(loginUsername, loginPassword);

            if (loggedIn) {
                System.out.println(loginSystem.returnLoginStatus(loginUsername, true));
            } else {
                System.out.println("Username or password incorrect, please try again.\n");
            }
        }

        input.close();
    }
}
