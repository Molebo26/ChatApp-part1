/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java
 */

package com.mycompany.main;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LoginTest {
    
    Login login = new Login();

    @Test
    public void testCheckUserNameValid() {
        assertTrue(login.checkUserName("k_yl"));
    }

    @Test
    public void testCheckUserNameInvalid() {
        assertFalse(login.checkUserName("kyle"));
    }

    @Test
    public void testCheckPasswordComplexityValid() {
        assertTrue(login.checkPasswordComplexity("Password1!"));
    }

    @Test
    public void testCheckPasswordComplexityInvalid() {
        assertFalse(login.checkPasswordComplexity("pass"));
    }

    @Test
    public void testCheckCellPhoneNumberValid() {
        assertTrue(login.checkCellPhoneNumber("+27831234567"));
    }

    @Test
    public void testCheckCellPhoneNumberInvalid() {
        assertFalse(login.checkCellPhoneNumber("0831234567"));
    }

    @Test
    public void testRegisterUserSuccess() {
        String result = login.registerUser("k_yl", "Password1!", "+27831234567");
        assertEquals("User successfully registered.", result);
    }

    @Test
    public void testLoginUserSuccess() {
        login.registerUser("k_yl", "Password1!", "+27831234567");
        assertTrue(login.loginUser("k_yl", "Password1!"));
    }

    @Test
    public void testLoginUserFail() {
        login.registerUser("k_yl", "Password1!", "+27831234567");
        assertFalse(login.loginUser("k_yl", "wrong"));
    }
}